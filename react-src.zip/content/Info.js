
// import './Info.css';

function Info() {
    let stringx = 'app';
    return (
        <div className="wrapper">
            <p>Info 영역입니다.</p>
            <p>{stringx}</p>
        </div>
    );
}

export default Info;
