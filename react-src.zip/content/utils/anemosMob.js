export const anemosMobList = [
    {id : '01', prop : 'WaterWind', lv : 23, name : '구드수드', xPos : 12, yPos : 16}
    ,{id : '02', prop : 'LightningIce', lv : 23, name : '네눈박이', xPos : 12, yPos : 16}
    ,{id : '03', prop : 'LightningIce', lv : 23, name : '보이드비늘', xPos : 10, yPos : 20}
    ,{id : '04', prop : 'FireEarth', lv : 24, name : '주니케라톱스', xPos : 10, yPos : 20}
    ,{id : '05', prop : 'WaterWind', lv : 24, name : '밭 그림자요괴', xPos : 10, yPos : 20}
    ,{id : '06', prop : 'LightningIce', lv : 24, name : '아네모스 비토', xPos : 10, yPos : 20}
    ,{id : '07', prop : 'FireEarth', lv : 25, name : '프리멜라파스', xPos : 10, yPos : 20}
    ,{id : '08', prop : 'FireEarth', lv : 25, name : '그림자망력', xPos : 10, yPos : 20}
    ,{id : '09', prop : 'FireEarth', lv : 25, name : '프리멜라파스', xPos : 9, yPos : 28}
    ,{id : '10', prop : 'WaterWind', lv : 25, name : '탄기', xPos : 9, yPos : 28}
    ,{id : '11', prop : 'LightningIce', lv : 23, name : '네눈박이', xPos : 9, yPos : 28}
    ,{id : '12', prop : 'WaterWind', lv : 23, name : '구드수드', xPos : 9, yPos : 28}
    ,{id : '13', prop : 'WaterWind', lv : 24, name : '밭 그림자요괴', xPos : 9, yPos : 28}
    ,{id : '14', prop : 'LightningIce', lv : 24, name : '아네모스아리오크', xPos : 9, yPos : 28}
];