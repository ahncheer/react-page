//속성 List
//https://www.freecodecamp.org/news/how-to-work-with-multiple-checkboxes-in-react/
export const propList = [
    {value : "LightningIce", name : "번개/얼음"},
    {value : "FireEarth", name : "불/땅"},
    {value : "WaterWind", name : "물/바람"},
    {value : "Elemental", name : "정령"},
    {value : "Undead", name : "언데드"}
];