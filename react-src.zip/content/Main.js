
import './Main.css';

const Main = (props) => {
    return (
        <div className="wrapper">
            <p>본문 영역입니다.</p>
        </div>
    );
}

export default Main;
